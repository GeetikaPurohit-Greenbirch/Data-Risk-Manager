import { Control } from './control.model';

describe('Control', () => {
  it('should create an instance', () => {
    expect(new Control()).toBeTruthy();
  });
});
