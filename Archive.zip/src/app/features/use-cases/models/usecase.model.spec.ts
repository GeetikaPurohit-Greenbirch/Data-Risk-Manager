import { Usecase } from './usecase.model';

describe('Usecase', () => {
  it('should create an instance', () => {
    expect(new Usecase()).toBeTruthy();
  });
});
