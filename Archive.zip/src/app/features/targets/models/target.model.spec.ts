import { Target } from './target.model';

describe('Target', () => {
  it('should create an instance', () => {
    expect(new Target()).toBeTruthy();
  });
});
