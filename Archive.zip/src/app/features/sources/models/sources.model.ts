export class SourceEntity {
    id!:number;
    source_name!:string;
    quality_of_service!:string;
    frequency_of_update!:number;
    schedule_of_update!:string;
    methodology_of_transfer!:string;
    source_type!:string;
    source_version_number!:string;
    source_status!:string;
    source_owner!:string;
    source_owner_email!:string;
  source_id: any;
 
}

 export class Sources {
    sourceEntity!: SourceEntity;
  }
  
