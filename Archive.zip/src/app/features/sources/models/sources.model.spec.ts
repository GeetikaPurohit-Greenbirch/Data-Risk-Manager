import { Sources } from './sources.model';

describe('Sources', () => {
  it('should create an instance', () => {
    expect(new Sources()).toBeTruthy();
  });
});
