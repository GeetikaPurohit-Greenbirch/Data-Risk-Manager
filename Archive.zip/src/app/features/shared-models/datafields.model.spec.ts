import { Datafields } from './datafields.model';

describe('Datafields', () => {
  it('should create an instance', () => {
    expect(new Datafields()).toBeTruthy();
  });
});
