export class Datafields {
    field_id! :number;
    field_name!:string;
    dqa_c!:string;
    commentary_a!:string;
    dqa_t!:string;
    commentary_t!:string;
    dqa_a!:string;
    commentary_p!:string;
    data_type!:string;
    field_length!:number;
    criticality!:string;
    entity_type!:string;
    entity_id!:number;
}
