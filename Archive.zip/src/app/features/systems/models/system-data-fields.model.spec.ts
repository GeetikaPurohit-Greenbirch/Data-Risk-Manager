import { SystemDataFields } from './system-data-fields.model';

describe('SystemDataFields', () => {
  it('should create an instance', () => {
    expect(new SystemDataFields()).toBeTruthy();
  });
});
