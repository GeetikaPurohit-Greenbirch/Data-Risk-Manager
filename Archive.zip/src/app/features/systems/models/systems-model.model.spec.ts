import { SystemsModel } from './systems-model.model';

describe('SystemsModel', () => {
  it('should create an instance', () => {
    expect(new SystemsModel()).toBeTruthy();
  });
});
