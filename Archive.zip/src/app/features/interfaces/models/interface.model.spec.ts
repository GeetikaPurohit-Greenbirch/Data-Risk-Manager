import { Interface } from './interface.model';

describe('Interface', () => {
  it('should create an instance', () => {
    expect(new Interface()).toBeTruthy();
  });
});
